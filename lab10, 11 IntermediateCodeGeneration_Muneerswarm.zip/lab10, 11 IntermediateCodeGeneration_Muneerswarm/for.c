main()
{
	int idx,nums,sum;
	float average;
	for(idx=0;idx<nums;idx=idx+1)
		sum = sum + idx;
	average = sum / nums;
}
