main()
{
	int i,n;
	int b[10];
	int sum;
	n = 10;
	for(i=0;i<n;i=i+1)
		sum = sum + b[i]; 
	sum = sum / n;
}

