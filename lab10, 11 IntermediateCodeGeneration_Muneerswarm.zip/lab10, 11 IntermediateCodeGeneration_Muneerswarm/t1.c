main()
{
	int a,b,c;
	a = b * -c + b * -c;
}

