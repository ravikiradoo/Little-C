main()
{
	int i;
	int x, y[10];
	x=y[i];
}

